import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Phone, Mail, Send, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';

export default function Contact() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('submitting');
    
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());

    try {
      const response = await fetch("https://formsubmit.co/ajax/uniqueideas8082@gmail.com", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _subject: "New Service Request | Unified Digital Hub",
          ...data
        })
      });

      if (response.ok) {
        setStatus('success');
        (e.target as HTMLFormElement).reset();
        setTimeout(() => setStatus('idle'), 5000);
      } else {
        setStatus('error');
        setTimeout(() => setStatus('idle'), 5000);
      }
    } catch (error) {
      setStatus('error');
      setTimeout(() => setStatus('idle'), 5000);
    }
  };

  return (
    <section id="contact" className="py-24 bg-transparent border-t border-white/5 relative z-10">
      <div className="absolute right-0 bottom-0 w-[500px] h-[500px] bg-indigo-600/5 blur-[150px] rounded-full -z-10 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-4">Contact Us</h2>
          <p className="text-lg text-slate-400 font-light max-w-2xl mx-auto">
            Get in touch with us for any digital service inquiries.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Contact Info */}
          <motion.div 
            className="lg:col-span-5 space-y-8"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl">
              <h3 className="text-xl font-bold text-white mb-6">Contact Information</h3>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-sky-500/10 border border-sky-500/20 flex items-center justify-center flex-shrink-0 text-sky-400">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Visit Us</p>
                    <p className="text-slate-300 text-sm leading-relaxed">Chinar-Bagh, Baramulla – 193101,<br/>UT J&K, India</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center flex-shrink-0 text-indigo-400">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Call Us</p>
                    <p className="text-slate-300 text-sm">8082713584</p>
                    <p className="text-slate-300 text-sm">7051856315</p>
                    <p className="text-slate-300 text-sm">9419205498</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-sky-500/10 border border-sky-500/20 flex items-center justify-center flex-shrink-0 text-sky-400">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Email Us</p>
                    <a href="mailto:uniqueideas8082@gmail.com" className="text-slate-300 text-sm block hover:text-sky-400 transition-colors">uniqueideas8082@gmail.com</a>
                    <a href="mailto:smarttech6612@gmail.com" className="text-slate-300 text-sm block hover:text-sky-400 transition-colors">smarttech6612@gmail.com</a>
                    <a href="mailto:nazirmohsin194@gmail.com" className="text-slate-300 text-sm block hover:text-sky-400 transition-colors">nazirmohsin194@gmail.com</a>
                  </div>
                </div>
              </div>
            </div>
            

          </motion.div>

          {/* Contact Form */}
          <motion.div 
            className="lg:col-span-7"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="bg-slate-900 border border-slate-800 p-8 md:p-12 rounded-3xl h-full shadow-xl">
               <h3 className="text-2xl font-bold text-white mb-8">Send a Message</h3>
               <form className="space-y-6" onSubmit={handleSubmit}>
                 {status === 'success' && (
                   <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 p-4 rounded-xl text-sm">
                     <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                     Message sent successfully! We will get back to you soon.
                   </div>
                 )}
                 {status === 'error' && (
                   <div className="flex items-center gap-3 bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl text-sm">
                     <AlertCircle className="w-5 h-5 flex-shrink-0" />
                     Something went wrong. Please try again or contact us directly.
                   </div>
                 )}

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div>
                     <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Full Name</label>
                     <input type="text" name="name" required className="w-full bg-black/40 border border-[#2A374A] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-all" placeholder="John Doe" />
                   </div>
                   <div>
                     <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Mobile Number</label>
                     <input type="tel" name="phone" required className="w-full bg-transparent border border-[#2A374A] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-all" placeholder="+91 00000 00000" />
                   </div>
                 </div>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div>
                     <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Email Address</label>
                     <input type="email" name="email" required className="w-full bg-transparent border border-[#2A374A] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-all" placeholder="john@example.com" />
                   </div>
                   <div>
                     <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Service Required</label>
                     <select name="service" required className="w-full bg-transparent border border-[#2A374A] rounded-xl px-4 py-3 text-sm text-slate-300 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-all appearance-none cursor-pointer">
                       <option value="">Select a service...</option>
                       <option value="pan">PAN Card Service</option>
                       <option value="passport">Passport Service</option>
                       <option value="scholarship">Scholarship Form</option>
                       <option value="other">Other</option>
                     </select>
                   </div>
                 </div>

                 <div>
                   <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Message</label>
                   <textarea name="message" required rows={4} className="w-full bg-transparent border border-[#2A374A] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-all resize-none" placeholder="How can we help you?"></textarea>
                 </div>

                 <button 
                  type="submit" 
                  disabled={status === 'submitting'}
                  className={`flex items-center justify-center w-full md:w-auto px-8 py-4 text-xs tracking-widest font-bold rounded-full transition-all uppercase shadow-lg shadow-sky-500/20 gap-2 \${
                    status === 'submitting' ? 'bg-slate-800 text-slate-400 cursor-not-allowed' : 'bg-sky-500 text-white hover:bg-sky-400'
                  }`}
                 >
                   {status === 'submitting' ? (
                     <>
                       <Loader2 className="w-4 h-4 animate-spin" /> Submitting...
                     </>
                   ) : (
                     <>
                       Submit Request <Send className="w-4 h-4" />
                     </>
                   )}
                 </button>
               </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
