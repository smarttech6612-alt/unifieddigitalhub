import React from 'react';
import { motion } from 'motion/react';
import { Bell, Search } from 'lucide-react';

export default function Updates() {
  return (
    <section id="updates" className="py-24 bg-transparent border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          <div className="lg:col-span-8">
            <div className="mb-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-sky-500/20 bg-sky-500/5 text-sky-400 text-[12px] font-bold uppercase tracking-[0.2em] mb-4">
                Notifications
              </div>
              <h2 className="font-display text-3xl font-black text-[#CBD5E1] tracking-tighter uppercase italic">Latest Updates</h2>
            </div>

            <div className="space-y-4">
              {[
                { type: "Government Notifications", title: "New guidelines for Aadhaar link with PAN card announced.", date: "Today" },
                { type: "Recruitment Updates", title: "SSC CGL 2024 Application forms are now available.", date: "Yesterday" },
                { type: "Scholarship", title: "Minority Scholarship last date extended.", date: "2 days ago" },
                { type: "Service Updates", title: "Passport server maintenance scheduled for weekend.", date: "3 days ago" }
              ].map((update, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: idx * 0.1 }}
                  className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex gap-4 hover:bg-slate-900 transition-colors"
                >
                  <div className="w-10 h-10 rounded-full bg-indigo-500/10 border border-indigo-500/20 flex flex-shrink-0 items-center justify-center text-indigo-400 mt-1">
                    <Bell className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold text-sky-400 uppercase tracking-widest">{update.type}</span>
                      <span className="text-xs text-slate-500">{update.date}</span>
                    </div>
                    <p className="text-white font-medium text-sm leading-relaxed">{update.title}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-4">
            <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-800 p-8 rounded-3xl h-full shadow-2xl">
              <h3 className="font-display text-[25px] font-black text-white tracking-tighter uppercase italic mb-6">Service Search</h3>
              <p className="text-sm text-slate-400 mb-6 leading-relaxed">
                Quickly locate any service you need. E.g., PAN Card, Scholarship, Driving License.
              </p>
              
              <div className="relative mb-8">
                <input 
                  type="text" 
                  placeholder="Search services..." 
                  className="w-full bg-black/40 border border-[#2A374A] rounded-full py-3 px-5 pl-12 text-white text-sm focus:outline-none focus:border-sky-500 transition-colors"
                />
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
              </div>

              <div>
                <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Popular Searches</h4>
                <div className="flex flex-wrap gap-2">
                  {["PAN Card", "Passport", "Scholarship", "Driving License", "GST Registration"].map((tag, i) => (
                    <span key={i} className="px-3 py-1 bg-slate-800/50 border border-[#2A374A] text-slate-300 text-xs rounded-full cursor-pointer hover:text-sky-400 hover:border-sky-500/50 transition-colors">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
}
