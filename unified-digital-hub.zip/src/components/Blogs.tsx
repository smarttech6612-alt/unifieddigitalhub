import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

const blogs = [
  {
    title: 'ChatGPT, MidJourney & Beyond: Tools That Redefine Content Creation',
    category: 'AI & Innovation',
    date: 'Mar 15, 2024'
  },
  {
    title: 'The Power of Micro-Content: How Small Posts Drive Big Impact',
    category: 'Content Strategy',
    date: 'Mar 10, 2024'
  },
  {
    title: 'The Secret to Viral AI-Generated Reels & Posts',
    category: 'Social Media',
    date: 'Mar 05, 2024'
  },
  {
    title: '10 Proven Social Media Marketing Strategies to Boost Engagement in 2025',
    category: 'Marketing Guides',
    date: 'Feb 28, 2024'
  },
  {
    title: 'The Ultimate 30-Day Social Media Growth Plan',
    category: 'Growth Hacks',
    date: 'Feb 20, 2024'
  },
  {
    title: '5 Data-Driven Social Media Strategies for Small Businesses',
    category: 'Data & Analytics',
    date: 'Feb 15, 2024'
  }
];

export default function Blogs() {
  return (
    <section id="blog" className="py-24 bg-transparent border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-4">Latest Insights</h2>
          <p className="text-lg text-slate-400 font-light max-w-2xl mx-auto">
            Stay ahead of the curve with our latest articles on digital marketing, AI, and growth strategies.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
          {blogs.map((blog, index) => (
            <motion.div
              key={index}
              className="bg-slate-900 p-6 rounded-2xl border border-slate-800 hover:bg-slate-900 hover:border-sky-500/30 transition-all duration-300 group flex flex-col justify-between"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-sky-400 bg-sky-500/5 border border-sky-500/20 px-3 py-1 rounded-full">
                    {blog.category}
                  </span>
                  <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">{blog.date}</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-4 group-hover:text-sky-400 transition-colors">
                  {blog.title}
                </h3>
              </div>
              <a href="#" className="inline-flex items-center text-slate-400 text-xs font-bold uppercase tracking-widest group-hover:text-sky-400 transition-colors mt-4">
                Read Article
                <ArrowRight className="ml-2 w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </a>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a href="#" className="inline-flex justify-center items-center px-8 py-4 text-xs font-bold tracking-widest uppercase rounded-full bg-sky-500 text-white hover:bg-sky-400 transition-all shadow-lg shadow-sky-500/20">
            Everything Marketing
            <ArrowRight className="ml-2 h-5 w-5" />
          </a>
        </div>
      </div>
    </section>
  );
}
