import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import logo from '../assets/images/udh_logo_1782532560244.jpg';

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-transparent">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-sky-600/10 blur-[120px] rounded-full -z-10 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col items-center"
          >
            <img src={logo} alt="Unified Digital Hub Logo" className="w-24 h-24 mb-6 object-cover rounded-full shadow-lg shadow-sky-500/20" />
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-sky-500/20 bg-sky-500/5 text-sky-400 text-[12px] font-bold uppercase tracking-[0.2em] mb-8">
              <span className="w-2 h-2 rounded-full bg-sky-500 animate-pulse"></span>
              Building Trust. Delivering Solutions. Empowering Lives Digitally.
            </span>
          </motion.div>
          <motion.h1 
            className="font-display text-[62px] font-black text-[#CBD5E1] leading-[1.1] mb-6 tracking-tighter italic uppercase"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            UNIFIED DIGITAL <br className="hidden md:block" />
            <span className="bg-gradient-to-r from-sky-400 via-indigo-300 to-sky-400 bg-clip-text text-transparent [font-family:'Times_New_Roman'] text-center block">
              HUB
            </span>
          </motion.h1>
          <motion.p 
            className="text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed font-light mb-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            One Stop Solution For All Your Digital & Government Service Needs. Providing reliable digital, government, educational, financial, and business services with efficiency and professionalism.
          </motion.p>

          <motion.div 
            className="flex flex-wrap justify-center gap-4 mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.25 }}
          >
            {[
              "Fast Service",
              "Secure Documentation",
              "Trusted Solutions",
              "Expert Support",
              "All Services Under One Roof"
            ].map((feature, i) => (
              <div key={i} className="flex items-center text-xs font-semibold text-slate-300 tracking-wider uppercase">
                <CheckCircle2 className="w-4 h-4 mr-1 text-sky-400" />
                {feature}
              </div>
            ))}
          </motion.div>

          <motion.div 
            className="flex flex-col sm:flex-row justify-center gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <a href="#appointments" className="inline-flex justify-center items-center px-8 py-4 text-xs tracking-widest font-bold rounded-full bg-sky-500 text-white hover:bg-sky-400 transition-all uppercase shadow-lg shadow-sky-500/20">
              Book Appointment
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
            <a href="#services" className="inline-flex justify-center items-center px-8 py-4 text-xs tracking-widest font-bold rounded-full text-white bg-transparent border border-white/20 hover:bg-white/10 transition-all uppercase">
              Explore Services
            </a>
            <a href="https://wa.me/917051856315" target="_blank" rel="noopener noreferrer" className="inline-flex justify-center items-center px-8 py-4 text-xs tracking-widest font-bold rounded-full text-sky-400 bg-sky-400/10 border border-sky-400/20 hover:bg-sky-400/20 transition-all uppercase">
              WhatsApp Support
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
