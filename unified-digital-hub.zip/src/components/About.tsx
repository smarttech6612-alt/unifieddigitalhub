import React from 'react';
import { motion } from 'motion/react';
import { Target, Eye, ShieldCheck } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-24 bg-transparent border-t border-white/5 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-sky-500/20 bg-sky-500/5 text-sky-400 text-[23px] font-bold uppercase tracking-[0.2em] mb-6">
              About Us
            </div>
            <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-6">
              Comprehensive Assistance for <span className="text-sky-400">All Your Needs</span>
            </h2>
            <p className="text-slate-400 text-lg leading-relaxed font-light mb-8">
              Unified Digital Hub offers comprehensive assistance for digital and government-related services, helping individuals, students, professionals, and businesses complete important tasks quickly and efficiently.
            </p>

            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
                  <Target className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-white font-bold mb-2">Our Mission</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    To simplify access to digital and government services through secure, reliable, and customer-focused solutions.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <Eye className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-white font-bold mb-2">Our Vision</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    To become the most trusted digital service hub by empowering people through technology and quality service.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
