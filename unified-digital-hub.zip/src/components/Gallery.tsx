import React from 'react';
import { motion } from 'motion/react';
import { Image as ImageIcon } from 'lucide-react';

const categories = [
  "Office Photos", "Customer Service Desk", "Service Activities", 
  "Achievement Highlights", "Community Events", "Digital Service Campaigns"
];

// Placeholder images
const images = [
  "https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&q=80&w=800",
  "https://images.unsplash.com/photo-1556761175-4b46a572b786?auto=format&fit=crop&q=80&w=800",
  "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80&w=800",
  "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&q=80&w=800",
  "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=800",
  "https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&q=80&w=800"
];

export default function Gallery() {
  return (
    <section id="gallery" className="py-24 bg-transparent border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <div className="max-w-2xl">
            <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-4">Photo Gallery</h2>
            <p className="text-lg text-slate-400 font-light">
              Glimpses of our workspace, team, and community activities.
            </p>
          </div>
          <div className="hidden md:flex gap-2 mt-4 md:mt-0 flex-wrap justify-end max-w-lg">
             <span className="text-[10px] font-bold text-sky-400 uppercase tracking-widest px-3 py-1 border border-sky-500/20 rounded-full bg-sky-500/5">All</span>
             <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-3 py-1 border border-slate-800 rounded-full hover:text-slate-300 cursor-pointer transition-colors">Office</span>
             <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-3 py-1 border border-slate-800 rounded-full hover:text-slate-300 cursor-pointer transition-colors">Events</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((src, index) => (
            <motion.div
              key={index}
              className="group relative aspect-[4/3] rounded-2xl overflow-hidden bg-slate-900 border border-[#2A374A]"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <img 
                src={src} 
                alt={`Gallery image \${index + 1}`} 
                className="w-full h-full object-cover opacity-70 transition-transform duration-700 group-hover:scale-110 group-hover:opacity-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent opacity-80"></div>
              
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                <span className="text-[10px] text-white font-bold uppercase tracking-widest">{categories[index]}</span>
                <div className="w-8 h-8 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center">
                  <ImageIcon className="w-4 h-4 text-white" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
