import React from 'react';
import { motion } from 'motion/react';
import { 
  FileText, Shield, Plane, GraduationCap, Building2, Wallet, 
  MonitorSmartphone, Briefcase, FileSignature, Map, CreditCard, PenTool
} from 'lucide-react';

const serviceCategories = [
  {
    title: "Core Document Services",
    icon: FileText,
    color: "text-sky-400",
    bg: "bg-sky-500/5",
    border: "border-sky-500/20",
    items: [
      { name: "Identity Services", list: "PAN Card, Aadhaar, Voter ID, e-PAN Download" },
      { name: "Certificate Services", list: "Domicile, Income, Caste, EWS, Birth, Death, Marriage, Disability" },
      { name: "Passport Services", list: "Application, Renewal, Appointment Booking" },
      { name: "Driving & Vehicle", list: "Learner's License, DL, Renewal, Int. Permit, RC Services, e-Challan" },
      { name: "Education Services", list: "Admission Forms, Scholarships, CUET, JEE, NEET, APAAR, DigiLocker" },
      { name: "Employment", list: "SSC, UPSC, Railway, Banking, Army, Police, NCS, Skill India" }
    ]
  },
  {
    title: "Government & Business",
    icon: Building2,
    color: "text-indigo-400",
    bg: "bg-indigo-500/5",
    border: "border-indigo-500/20",
    items: [
      { name: "Banking & Financial", list: "GST Registration/Filing, ITR Filing, NPS, FASTag" },
      { name: "Government Schemes", list: "PM Kisan, Ayushman Bharat, e-Shram, Labour Card, Pension, Ration Card" },
      { name: "Business Services", list: "UDYAM, MSME, FSSAI, IEC, Startup India, DSC" },
      { name: "Land & Property", list: "Land Records, Jamabandi, Fard, Mutation, Property Tax" },
      { name: "Travel & Booking", list: "Train, Flight, Bus Tickets, Hotel Booking, Travel Insurance" },
      { name: "Utility Services", list: "Electricity, Water, Gas Bills, Recharges, Broadband" }
    ]
  },
  {
    title: "Digital & Support Services",
    icon: MonitorSmartphone,
    color: "text-sky-400",
    bg: "bg-sky-500/5",
    border: "border-sky-500/20",
    items: [
      { name: "Digital Services", list: "DigiLocker Setup, Email Creation, Form Filling, PDF Tools, e-Sign" },
      { name: "Digital Payment", list: "UPI Setup, Mobile Banking, Internet Banking Support" },
      { name: "Typing & Docs", list: "English/Hindi/Urdu Typing, Resumes, Biodata, Affidavits, Data Entry" },
      { name: "Designing Services", list: "Banners, Posters, Logos, Certificates, Wedding/Invitation Cards" },
      { name: "Download Services", list: "Aadhaar, PAN, Voter ID, DL, RC, Admit Cards, Results, Pension Slips" },
      { name: "Popular Bill Payments", list: "Mobile, DTH, Broadband, Utility Bill Payments" }
    ]
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-transparent relative border-t border-white/5">
      <div className="absolute right-0 top-1/4 w-[400px] h-[400px] bg-indigo-600/5 blur-[120px] rounded-full -z-10 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-sky-500/20 bg-sky-500/5 text-sky-400 text-[14px] font-bold uppercase tracking-[0.2em] mb-6">
            Our Expertise
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-4">Our Services</h2>
          <p className="text-lg text-slate-400 font-light">
            One Stop Solution for Digital, Government, and Business Services.
          </p>
        </div>
        
        <div className="space-y-16">
          {serviceCategories.map((category, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex items-center gap-4 mb-8">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center \${category.color} \${category.bg} border \${category.border}`}>
                  <category.icon className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold text-white uppercase tracking-wider">{category.title}</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.items.map((item, itemIdx) => (
                  <div 
                    key={itemIdx}
                    className="group p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:bg-slate-900 hover:border-sky-500/30 transition-all duration-300"
                  >
                    <h4 className="text-white font-bold text-lg mb-2 group-hover:text-sky-400 transition-colors">{item.name}</h4>
                    <p className="text-slate-500 text-sm leading-relaxed">
                      {item.list}
                    </p>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
