import React from 'react';
import { motion } from 'motion/react';
import { Star } from 'lucide-react';

const testimonials = [
  {
    text: "Excellent service and quick processing. They made getting my documents sorted completely hassle-free.",
    name: "Customer Review",
    role: "Verified Client"
  },
  {
    text: "Professional assistance for government and documentation services. Highly recommend for any official paperwork.",
    name: "Customer Review",
    role: "Verified Client"
  },
  {
    text: "Reliable, trustworthy, and customer-friendly support. They guided me through every step.",
    name: "Customer Review",
    role: "Verified Client"
  }
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-transparent border-t border-white/5 relative">
      <div className="absolute right-1/4 bottom-0 w-[500px] h-[300px] bg-sky-600/5 blur-[120px] rounded-full -z-10 pointer-events-none"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-4">Customer Reviews</h2>
          <p className="text-lg text-slate-400 font-light max-w-2xl mx-auto">
            See what our clients say about their experience with Unified Digital Hub.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              className="bg-slate-900 p-8 rounded-2xl border border-slate-800"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-slate-300 mb-8 italic text-sm leading-relaxed">"{testimonial.text}"</p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-sky-500/10 border border-sky-500/20 rounded-full flex items-center justify-center text-sky-400 font-bold text-lg">
                  {testimonial.name.charAt(0)}
                </div>
                <div className="ml-4">
                  <h4 className="font-bold text-white tracking-tight">{testimonial.name}</h4>
                  <p className="text-[10px] font-bold text-sky-400 uppercase tracking-widest">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
