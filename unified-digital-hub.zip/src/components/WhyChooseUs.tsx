import React from 'react';
import { motion } from 'motion/react';
import { Zap, ShieldCheck, ThumbsUp, Clock, Users, Building } from 'lucide-react';

const reasons = [
  { icon: Zap, title: "Fast Processing", color: "text-amber-400" },
  { icon: ShieldCheck, title: "Secure Documentation", color: "text-sky-400" },
  { icon: ThumbsUp, title: "Trusted Solutions", color: "text-blue-400" },
  { icon: Users, title: "Professional Assistance", color: "text-indigo-400" },
  { icon: ShieldCheck, title: "Customer Satisfaction", color: "text-pink-400" },
  { icon: Clock, title: "Reliable Support", color: "text-sky-400" },
  { icon: Building, title: "One-Stop Service Center", color: "text-purple-400" },
  { icon: Clock, title: "Open All Days", color: "text-teal-400" }
];

export default function WhyChooseUs() {
  return (
    <section className="py-24 bg-transparent border-t border-white/5 relative">
       <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-sky-600/5 blur-[120px] rounded-full -z-10 pointer-events-none"></div>
       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-sky-500/20 bg-sky-500/5 text-sky-400 text-[18px] font-bold uppercase tracking-[0.2em] mb-6">
            Advantages
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-4">Why Choose Us?</h2>
          <p className="text-lg text-slate-400 font-light max-w-2xl mx-auto">
            Experience the best in class service with our dedicated professional approach.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {reasons.map((reason, index) => (
            <motion.div
              key={index}
              className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex flex-col items-center text-center group hover:bg-slate-900 hover:border-sky-500/30 transition-all"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
            >
              <div className={`w-12 h-12 rounded-full bg-slate-800/80 flex items-center justify-center mb-4 \${reason.color} group-hover:scale-110 transition-transform`}>
                <reason.icon className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-white tracking-wide">{reason.title}</h3>
            </motion.div>
          ))}
        </div>
       </div>
    </section>
  );
}
