import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    q: "What are your working hours?",
    a: "We are open from 9:00 AM to 8:00 PM, seven days a week to ensure you always have access to our services."
  },
  {
    q: "Do I need an appointment?",
    a: "Walk-ins are welcome and regularly served, but scheduling an appointment is highly recommended for priority assistance and shorter waiting times."
  },
  {
    q: "Do you provide WhatsApp support?",
    a: "Yes, our dedicated WhatsApp support is available during business hours to assist you with queries and updates."
  },
  {
    q: "Which services do you provide?",
    a: "We provide a comprehensive range of Government, Educational, Business, Travel, Financial, Digital, and Documentation services all under one roof."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 bg-transparent border-t border-white/5 relative">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-4">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div 
              key={index}
              className={`border \${openIndex === index ? 'border-sky-500/50 bg-slate-900' : 'border-slate-800 bg-slate-900'} rounded-2xl overflow-hidden transition-colors`}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <button 
                className="w-full px-6 py-5 flex items-center justify-between focus:outline-none"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <span className="text-white font-bold text-left">{faq.q}</span>
                <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform duration-300 \${openIndex === index ? 'rotate-180 text-sky-400' : ''}`} />
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-5 text-slate-400 text-sm leading-relaxed">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
