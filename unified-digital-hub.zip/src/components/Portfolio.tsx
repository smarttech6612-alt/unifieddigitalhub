import React from 'react';
import { motion } from 'motion/react';
import { ExternalLink } from 'lucide-react';

const projects = [
  { name: 'Evolve AI', category: 'AI Product Launch', image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=800' },
  { name: 'Bourgeois Dental Clinic', category: 'Healthcare SEO & Web', image: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=800' },
  { name: 'NutriEuphoria', category: 'DTC Brand Scaling', image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80&w=800' },
  { name: 'ClarityClick', category: 'B2B SaaS Growth', image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800' },
  { name: 'PCWINGS', category: 'Tech Ecommerce', image: 'https://images.unsplash.com/photo-1593640408182-31c70c8268f5?auto=format&fit=crop&q=80&w=800' },
  { name: "Jiya's Salon 'N' Spa", category: 'Local Business Marketing', image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&q=80&w=800' }
];

export default function Portfolio() {
  return (
    <section id="work" className="py-24 bg-transparent border-t border-white/5 relative">
      <div className="absolute left-1/4 top-0 w-[400px] h-[300px] bg-indigo-600/5 blur-[120px] rounded-full -z-10 pointer-events-none"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <div className="max-w-2xl">
            <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-4">Featured Work</h2>
            <p className="text-lg text-slate-400 font-light">
              Discover how we've helped businesses across industries scale and succeed in the digital landscape.
            </p>
          </div>
          <a href="#" className="hidden md:flex items-center text-sky-400 text-xs font-bold tracking-widest uppercase hover:text-sky-300 mt-4 md:mt-0 transition-colors">
            View all case studies
            <ExternalLink className="ml-2 w-4 h-4" />
          </a>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              className="group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 aspect-[4/3] cursor-pointer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <img 
                src={project.image} 
                alt={project.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#020617]/90 via-[#020617]/40 to-transparent opacity-80 transition-opacity duration-300"></div>
              
              <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                <span className="text-sky-400 font-bold text-[10px] tracking-widest uppercase mb-2 block">{project.category}</span>
                <h3 className="text-xl font-bold text-white flex justify-between items-center bg-transparent">
                  {project.name}
                  <ExternalLink className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </h3>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-8 text-center md:hidden">
          <a href="#" className="inline-flex items-center text-sky-400 text-xs font-bold tracking-widest uppercase hover:text-sky-300 transition-colors">
            View all case studies
            <ExternalLink className="ml-2 w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
