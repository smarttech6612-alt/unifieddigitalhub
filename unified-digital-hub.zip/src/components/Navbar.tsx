import React from 'react';
import { Menu, X } from 'lucide-react';
import logo from '../assets/images/udh_logo_1782532560244.jpg';

export default function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="fixed w-full z-50 bg-[#050B14]/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Unified Digital Hub Logo" className="w-10 h-10 object-cover rounded-full" />
            <span className="text-xl font-bold tracking-tight text-[#CBD5E1] uppercase tracking-wider hidden sm:block">
              UNIFIED <span className="text-sky-400">DIGITAL</span> HUB
            </span>
          </div>
          <div className="hidden md:flex gap-8 text-xs font-semibold tracking-widest uppercase items-center">
            <a href="#about" className="text-slate-400 hover:text-sky-400 transition-colors">About</a>
            <a href="#services" className="text-slate-400 hover:text-sky-400 transition-colors">Services</a>
            <a href="#appointments" className="text-slate-400 hover:text-sky-400 transition-colors">Booking</a>
            <a href="#updates" className="text-slate-400 hover:text-sky-400 transition-colors">Updates</a>
            <a href="#contact" className="ml-4 bg-sky-500 text-white px-6 py-2.5 rounded-full font-bold hover:bg-sky-400 transition-all shadow-lg shadow-sky-500/20">
              CONTACT US
            </a>
          </div>
          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-400 hover:text-white">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-[#050B14]/95 backdrop-blur-md border-b border-white/5 absolute w-full">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 text-xs font-semibold tracking-widest uppercase">
            <a href="#about" className="block px-3 py-2 text-slate-400 hover:bg-slate-900 rounded-md">About</a>
            <a href="#services" className="block px-3 py-2 text-slate-400 hover:bg-slate-900 rounded-md">Services</a>
            <a href="#appointments" className="block px-3 py-2 text-slate-400 hover:bg-slate-900 rounded-md">Booking</a>
            <a href="#updates" className="block px-3 py-2 text-slate-400 hover:bg-slate-900 rounded-md">Updates</a>
            <a href="#contact" className="block px-3 py-2 text-sky-400 font-bold hover:bg-slate-900 rounded-md">CONTACT US</a>
          </div>
        </div>
      )}
    </nav>
  );
}
