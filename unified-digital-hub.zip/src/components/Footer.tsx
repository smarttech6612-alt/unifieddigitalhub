import React from 'react';
import logo from '../assets/images/udh_logo_1782532560244.jpg';

export default function Footer() {
  return (
    <footer className="bg-transparent text-[#CBD5E1] py-16 border-t border-white/5 relative z-10">
      <div className="absolute left-1/2 bottom-0 -translate-x-1/2 w-[800px] h-[300px] bg-sky-600/5 blur-[150px] rounded-full -z-10 pointer-events-none"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <img src={logo} alt="Unified Digital Hub Logo" className="w-12 h-12 object-cover rounded-full shadow-lg shadow-sky-500/10" />
              <span className="text-xl font-bold tracking-tight text-white uppercase tracking-wider block">
                UNIFIED <span className="text-sky-400">DIGITAL</span> HUB
              </span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed max-w-sm mb-4">
              Building Trust. Delivering Solutions. Empowering Lives Digitally.
              One Stop Solution For All Your Digital & Government Service Needs.
            </p>
            <div className="text-[10px] uppercase tracking-widest font-bold text-sky-400 mb-2">
              Business Hours: <span className="text-white ml-2 block sm:inline mt-1 sm:mt-0">Mon - Sun, 9:00 AM - 8:00 PM</span>
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6 text-sm uppercase tracking-widest">Quick Links</h4>
            <ul className="space-y-4 text-slate-400 text-sm font-medium">
              <li><a href="#home" className="hover:text-sky-400 transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-sky-400 transition-colors">About Us</a></li>
              <li><a href="#services" className="hover:text-sky-400 transition-colors">Services</a></li>
              <li><a href="#appointments" className="hover:text-sky-400 transition-colors">Appointment Booking</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6 text-sm uppercase tracking-widest">More Links</h4>
            <ul className="space-y-4 text-slate-400 text-sm font-medium">
              <li><a href="#updates" className="hover:text-sky-400 transition-colors">Latest Updates</a></li>
              <li><a href="#gallery" className="hover:text-sky-400 transition-colors">Gallery</a></li>
              <li><a href="#contact" className="hover:text-sky-400 transition-colors">Contact Us</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/5 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center text-slate-500 text-[10px] uppercase tracking-[0.25em] font-semibold">
          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-8 mb-4 md:mb-0">
            <p>&copy; {new Date().getFullYear()} Unified Digital Hub // All Rights Reserved.</p>
            <div className="hidden md:block h-4 w-px bg-slate-800"></div>
            <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">
              Follow Us:
            </div>
            <div className="flex gap-4">
              <a href="https://wa.me/917051856315" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">WhatsApp</a>
              <a href="#" className="hover:text-white transition-colors">Facebook</a>
              <a href="#" className="hover:text-white transition-colors">Instagram</a>
              <a href="#" className="hover:text-white transition-colors">YouTube</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
