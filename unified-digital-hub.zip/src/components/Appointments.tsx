import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, Ticket, Clock, CheckCircle, Loader2 } from 'lucide-react';

export default function Appointments() {
  const [token, setToken] = useState<string | null>(null);
  const [waitTime, setWaitTime] = useState<number | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateToken = () => {
    setIsGenerating(true);
    // Simulate network delay for a better user experience
    setTimeout(() => {
      const randomToken = 'UDH-' + Math.floor(1000 + Math.random() * 9000);
      const randomWait = Math.floor(5 + Math.random() * 25);
      setToken(randomToken);
      setWaitTime(randomWait);
      setIsGenerating(false);
    }, 800);
  };

  return (
    <section id="appointments" className="py-24 bg-transparent border-t border-white/5 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Scheduling */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-sky-500/20 bg-sky-500/5 text-sky-400 text-[20px] font-bold uppercase tracking-[0.2em] mb-6">
              Booking
            </div>
            <h2 className="font-display text-3xl md:text-4xl font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-6">
              Appointment & Visit Scheduling
            </h2>
            <p className="text-slate-400 text-lg leading-relaxed font-light mb-8">
              Book your visit in advance and receive priority assistance for a smoother experience.
            </p>

            <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl mb-8">
              <div className="flex items-center gap-4 mb-4">
                <Clock className="text-sky-400 w-6 h-6" />
                <h3 className="text-white font-bold uppercase tracking-widest text-sm">Available Hours</h3>
              </div>
              <div className="text-slate-300">
                <span className="font-bold">Monday – Sunday:</span> 9:00 AM – 8:00 PM
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-white font-bold text-sm uppercase tracking-widest mb-4">Benefits of Booking</h4>
              {["Priority Assistance", "Reduced Waiting Time", "Dedicated Support", "Faster Processing", "Convenient Scheduling"].map((benefit, i) => (
                <div key={i} className="flex items-center text-slate-300 text-sm">
                  <CheckCircle className="w-4 h-4 mr-3 text-sky-400" />
                  {benefit}
                </div>
              ))}
            </div>
          </motion.div>

          {/* Token System */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col"
          >
            <div className="bg-gradient-to-br from-indigo-900/20 to-slate-800/20 border border-sky-500/20 p-8 rounded-3xl h-full flex flex-col justify-center relative overflow-hidden">
               <div className="absolute top-0 right-0 p-6 opacity-10 pointer-events-none">
                 <Ticket className="w-48 h-48 text-sky-400" />
               </div>

               <h3 className="font-display text-2xl font-black text-white tracking-tighter uppercase italic mb-4">
                 Online Token System
               </h3>
               <p className="text-slate-400 text-sm leading-relaxed mb-8 relative z-10">
                 Skip unnecessary waiting by generating a service token before your visit. Enjoy queue management and estimated waiting times.
               </p>

               <div className="bg-slate-900 border border-indigo-500/30 p-6 rounded-2xl relative z-10 mb-8 backdrop-blur-sm shadow-xl">
                 <div className="text-center border-b border-white/5 pb-4 mb-4">
                   <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">
                     {token ? 'Your Token' : 'Sample Token'}
                   </div>
                   <div className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-indigo-400 tracking-tighter">
                     {isGenerating ? '...' : (token || 'UDH-1025')}
                   </div>
                 </div>
                 <div className="flex justify-between items-center text-sm font-semibold">
                   <span className="text-slate-400">Est. Wait:</span>
                   <span className="text-sky-400 bg-sky-400/10 px-3 py-1 rounded-full text-xs">
                     {isGenerating ? '...' : `${waitTime || 10} Minutes`}
                   </span>
                 </div>
               </div>

               <button 
                 onClick={handleGenerateToken}
                 disabled={isGenerating}
                 className={`relative z-10 w-full flex justify-center items-center px-8 py-4 text-xs tracking-widest font-bold rounded-full transition-all uppercase shadow-lg shadow-sky-500/20 \${
                   isGenerating ? 'bg-slate-800 text-slate-400 cursor-not-allowed' : 'bg-sky-500 text-white hover:bg-sky-400'
                 }`}
               >
                 {isGenerating ? (
                   <>
                     <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating...
                   </>
                 ) : (
                   token ? 'Generate New Token' : 'Generate Token Now'
                 )}
               </button>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
