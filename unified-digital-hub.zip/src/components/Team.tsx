import React from 'react';
import { motion } from 'motion/react';
import { User, ShieldAlert } from 'lucide-react';

export default function Team() {
  return (
    <section className="py-24 bg-transparent border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-sky-500/20 bg-sky-500/5 text-sky-400 text-[15px] font-bold uppercase tracking-[0.2em] mb-6">
            Leadership
          </div>
          <h2 className="font-display text-[50px] font-black text-[#CBD5E1] tracking-tighter uppercase italic mb-4">Our Team</h2>
        </div>

        <div className="max-w-3xl mx-auto mb-16">
          <motion.div 
            className="bg-slate-900 border border-slate-800 p-8 md:p-12 rounded-3xl flex flex-col md:flex-row items-center gap-8 text-center md:text-left"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-sky-500 to-indigo-600 p-1 flex-shrink-0">
              <div className="w-full h-full bg-transparent rounded-full flex items-center justify-center overflow-hidden">
                 <User className="w-16 h-16 text-slate-500" strokeWidth={1} />
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white mb-1">Mohsin Nazir</h3>
              <p className="text-sky-400 text-xs font-bold uppercase tracking-widest mb-4">Founder & Digital Service Consultant</p>
              <p className="text-slate-400 text-sm leading-relaxed max-w-xl">
                Providing professional assistance in digital, government, educational, financial, and documentation services with a commitment to reliability, transparency, and customer satisfaction.
              </p>
            </div>
          </motion.div>
        </div>

        <h3 className="text-center text-sm font-bold text-slate-500 uppercase tracking-widest mb-8">Support Team</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {["Customer Service Executive", "Technical Support Executive", "Documentation Executive"].map((role, idx) => (
            <motion.div
              key={idx}
              className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex flex-col items-center text-center group hover:border-sky-500/30 transition-colors"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
            >
              <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mb-4 text-slate-400 group-hover:text-sky-400 group-hover:bg-sky-500/10 transition-colors">
                <User className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-white mb-1">Expert Staff</h4>
              <p className="text-[10px] text-sky-400 font-bold uppercase tracking-widest">{role}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
