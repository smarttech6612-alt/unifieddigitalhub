/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import WhyChooseUs from './components/WhyChooseUs';
import Appointments from './components/Appointments';
import Updates from './components/Updates';
import Testimonials from './components/Testimonials';
import Gallery from './components/Gallery';
import Team from './components/Team';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-transparent text-[#CBD5E1] flex flex-col font-sans overflow-x-hidden selection:bg-cyan-500/30 selection:text-cyan-200 relative">
      {/* High-tech Background */}
      <div className="fixed inset-0 z-[-1] bg-[#050B14]">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00ffff08_1px,transparent_1px),linear-gradient(to_bottom,#00ffff08_1px,transparent_1px)] bg-[size:40px_40px]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_800px_at_50%_-30%,#00ffff15,transparent)]"></div>
        <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_600px_at_100%_20%,#0044ff0a,transparent)]"></div>
        <div className="absolute bottom-0 left-0 w-full h-full bg-[radial-gradient(circle_600px_at_0%_80%,#0044ff0a,transparent)]"></div>
      </div>
      <Navbar />
      <main className="flex-grow">
        <Hero />
        <About />
        <Services />
        <WhyChooseUs />
        <Appointments />
        <Updates />
        <Testimonials />
        <Gallery />
        <Team />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
